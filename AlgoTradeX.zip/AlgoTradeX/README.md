# AlgoTradeX · AI Trading Studio

> Professional-grade algorithmic trading research platform —
> ensemble signal aggregation, price forecasting, and strategy backtesting.

---

## Screenshots

```
⚡ Command Deck  |  🕯️ Chart  |  🧪 Strategy Lab  |  🔮 Forecast  |  📊 Indicators  |  🗂️ Raw Data
```

---

## Architecture

```
AlgoTradeX/
├── app.py                          ← Streamlit dashboard (UI only — no heavy logic)
│
├── strategies/
│   ├── algotradex_strategies.py    ← 26 indicators (OSC + MA + custom builder)
│   └── signal_engine.py           ← Ensemble Signal Aggregator
│
├── models/
│   └── forecaster.py              ← Prophet + TimesFM + Naive ensemble
│
├── utils/
│   ├── data_utils.py              ← yfinance, CSV loader, OHLCV validation
│   └── backtesting_engine.py      ← Vectorised backtest, strategy registry
│
├── requirements.txt
├── README.md
└── ARCHITECTURE.md
```

### Layer separation principle

```
DATA LAYER    → utils/data_utils.py
  ↓
ENGINE LAYER  → strategies/signal_engine.py   (40% Technical)
               models/forecaster.py           (30% Forecast)
               [vaderSentiment]               (30% Sentiment)
  ↓
UI LAYER      → app.py   (all st.* calls live here, zero heavy logic)
```

---

## Quick Start

### 1. Install dependencies

```bash
# Create an isolated environment (recommended)
conda create -n algotradex python=3.11 -y
conda activate algotradex

# Install requirements
pip install -r requirements.txt
```

### 2. Run the dashboard

```bash
cd AlgoTradeX
streamlit run app.py
```

The dashboard opens at **http://localhost:8501**.

### 3. Optional — enable TimesFM (zero-shot forecasting)

```bash
pip install timesfm
```

Then check **"Enable TimesFM"** in the sidebar. The first run downloads
the 200M-parameter Google model (~800MB). Subsequent runs use the local cache.

---

## Features

### ⚡ Command Deck
- Weighted Majority Consensus Final Signal (Buy / Sell / Hold)
- Confidence gauge (0–95%)
- Component bar chart: Technical · Sentiment · Forecast contributions
- 5 live KPI cards: price, signal score, confidence, forecast, band

### 🕯️ Price Chart
- Interactive candlestick with EMA20 / EMA50 overlays
- Volume subplot with bull/bear colouring
- Hover-to-inspect OHLCV

### 🧪 Strategy Lab (Backtesting Sandbox)
Visually distinct dark-room theme signals simulated data.

**Built-in strategies:**

| Key | Description |
|-----|-------------|
| `dual_ma_crossover` | Long when EMA(short) > EMA(long), else flat |
| `macd_trend` | Long when MACD line > signal line |
| `rsi_mean_reversion` | Buy RSI<30, sell RSI>70 |
| `buy_and_hold` | Always invested — passive benchmark |

**Performance Dossier:**
- Sharpe Ratio, Sortino Ratio, Calmar Ratio, Max Drawdown
- Interactive equity curve vs buy-and-hold with trade markers
- Drawdown waterfall + rolling 30-day Sharpe
- Monthly return heatmap (year × month)
- Full trade log with entry/exit prices and costs

### 🔮 Forecasting
Price forecast for tomorrow using a model ensemble:

| Model | Weight | Notes |
|-------|--------|-------|
| Meta Prophet | 45% | Yearly + weekly seasonality |
| Google TimesFM | 45% | Zero-shot, 200M params |
| Naive linear | 10% floor | Always available |

Output: point estimate + ±1σ confidence band.

### 📊 Indicator Panel
All 26 indicators from the strategy engine, filterable by signal direction.

**Oscillators (11):** RSI, Stochastic, CCI, ADX, AO, Momentum,
MACD, Stoch RSI, Williams %R, Bull Bear Power, Ultimate Oscillator.

**Moving Averages (15):** EMA/SMA at 10/20/30/50/100/200,
Ichimoku Base Line, VWMA(20), Hull MA(9).

---

## Signal Aggregation — Mathematical Logic

### Ensemble Score

```
Ensemble = W_tech × S_tech + W_sent × S_sent + W_fore × S_fore

where:
  W_tech = 0.40,  S_tech = (buy_count - sell_count) / total ∈ [-1, +1]
  W_sent = 0.30,  S_sent = VADER compound score             ∈ [-1, +1]
  W_fore = 0.30,  S_fore = clip((F - P) / P × 50, -1, 1)  ∈ [-1, +1]
    F = forecast price, P = last close price
```

### Final Signal Decision

```
Ensemble ≥  0.15  →  Buy
Ensemble ≤ -0.15  →  Sell
Otherwise          →  Hold
```

### Confidence Score

```
Confidence = clip(0.50 + 0.45 × |Ensemble|, 0.50, 0.95)
```

Maps a maximum-magnitude ensemble score to 95% confidence;
neutral signals floor at 50%.

---

## Adding a Custom Strategy

```python
# 1. Define a signal generator function
def signal_bollinger(close: pd.Series, window: int = 20, n_std: float = 2.0):
    ma    = close.rolling(window).mean()
    std   = close.rolling(window).std()
    upper = ma + n_std * std
    lower = ma - n_std * std
    pos   = pd.Series(0.0, index=close.index)
    pos[close < lower] = 1.0   # buy when below lower band
    pos[close > upper] = 0.0   # sell when above upper band
    return pos.ffill().fillna(0)

# 2. Register it
from utils.backtesting_engine import STRATEGY_REGISTRY
STRATEGY_REGISTRY["bollinger"] = {
    "label":  "Bollinger Band Reversion",
    "params": {"window": 20, "n_std": 2.0},
    "fn":     signal_bollinger,
}

# 3. It now appears in the sidebar dropdown automatically.
```

---

## Troubleshooting

| Problem | Fix |
|---------|-----|
| `ModuleNotFoundError` | Run from the `AlgoTradeX/` directory: `streamlit run app.py` |
| `No data returned for ticker` | Check ticker spelling (e.g. `RELIANCE.NS` for NSE) |
| Prophet install fails on Apple Silicon | `conda install -c conda-forge prophet` |
| TimesFM OOM | Needs ~4GB RAM; disable it in the sidebar |
| VADER not scoring | `pip install vaderSentiment` |

---

## Roadmap

- [ ] Live news headline ingestion (NewsAPI / RSS)
- [ ] Walk-forward optimisation framework
- [ ] Options Greeks panel
- [ ] Portfolio-level multi-ticker view
- [ ] Real-time WebSocket price feed integration
