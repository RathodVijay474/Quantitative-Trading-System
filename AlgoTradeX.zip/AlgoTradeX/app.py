"""
app.py  —  AlgoTradeX · AI Trading Studio
==========================================
Clean, dark-mode Streamlit dashboard.

Architecture (3 layers):
  UI      → app.py              (this file — display only, no heavy logic)
  Engine  → strategies/signal_engine.py, models/forecaster.py
  Data    → utils/data_utils.py, utils/backtesting_engine.py

User flow:
  1. Enter Ticker + date range → click "Analyse"
  2. Progress bar tracks: Data → Indicators → Forecast → Ensemble
  3. Interactive dashboard renders:
     Tab 1: Command Deck       (Ensemble signal, gauge, component breakdown)
     Tab 2: Candlestick Chart  (price + buy/sell markers)
     Tab 3: Strategy Lab       (backtest + Performance Dossier)
     Tab 4: Forecasting        (Prophet / TimesFM price range)
     Tab 5: Indicator Panel    (all 26 indicators, signal table)
     Tab 6: Raw Data           (downloads + frame inspector)

Run:
  cd AlgoTradeX
  streamlit run app.py
"""

from __future__ import annotations

import sys
import os

# Ensure AlgoTradeX directory is on path
_DIR = os.path.dirname(os.path.abspath(__file__))
if _DIR not in sys.path:
    sys.path.insert(0, _DIR)

import warnings
from datetime import date, timedelta
from typing import Any

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import streamlit as st

warnings.filterwarnings("ignore")

# ── Internal imports ──────────────────────────────────────────────────────────
from utils.data_utils import (
    fetch_yfinance,
    load_csv_upload,
    slice_date_range,
    validate_ohlcv,
    compute_full_metrics,
    annualised_vol,
)
from utils.backtesting_engine import (
    run_named_strategy,
    list_strategies,
    STRATEGY_REGISTRY,
)
from strategies.signal_engine import (
    compute_ensemble_signal,
    build_signal_component_df,
    EnsembleSignal,
    BUY, SELL, NEUTRAL,
)
from models.forecaster import run_forecast, ForecastResult

# ═══════════════════════════════════════════════════════════════════════════
# Design tokens
# ═══════════════════════════════════════════════════════════════════════════
BG        = "#080d18"
SURFACE   = "#0f1a2b"
BORDER    = "#1a2d45"
TEXT      = "#dde6f0"
MUTED     = "#5a7a9a"
ACCENT    = "#22d3ee"       # cyan
BULL      = "#10b981"       # emerald
SELL_C    = "#f43f5e"       # rose
GOLD      = "#f59e0b"       # amber
PURPLE    = "#a78bfa"       # violet

SIGNAL_COLOR = {BUY: BULL, SELL: SELL_C, NEUTRAL: GOLD}
PLOTLY_BASE  = dict(
    template="plotly_dark",
    paper_bgcolor="rgba(0,0,0,0)",
    plot_bgcolor="rgba(0,0,0,0)",
    font=dict(family="'IBM Plex Mono', monospace", color=TEXT, size=12),
    margin=dict(l=24, r=24, t=48, b=24),
    hovermode="x unified",
    hoverlabel=dict(bgcolor=SURFACE, font_color=TEXT, font_size=12),
)


# ═══════════════════════════════════════════════════════════════════════════
# CSS injection
# ═══════════════════════════════════════════════════════════════════════════
_CSS = f"""
<style>
@import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@300;400;600;700&family=Space+Grotesk:wght@400;600;700&display=swap');

html, body, [class*="css"] {{
  font-family: 'Space Grotesk', sans-serif;
  color: {TEXT};
}}
.stApp {{
  background: {BG};
  background-image:
    radial-gradient(ellipse at 8% 4%,  rgba(34,211,238,0.07) 0%, transparent 38%),
    radial-gradient(ellipse at 92% 8%,  rgba(167,139,250,0.05) 0%, transparent 33%),
    radial-gradient(ellipse at 50% 97%, rgba(245,158,11,0.04)  0%, transparent 38%);
}}

/* Sidebar */
[data-testid="stSidebar"] {{
  background: #090f1c !important;
  border-right: 1px solid {BORDER};
}}

/* Main container */
.main .block-container {{
  max-width: 1600px;
  padding-top: 0.8rem;
}}

/* Tabs */
.stTabs [data-baseweb="tab-list"] {{
  gap: 0; background: #090f1c; border-radius: 10px;
  padding: 4px; border: 1px solid {BORDER};
}}
.stTabs [data-baseweb="tab"] {{
  font-family: 'IBM Plex Mono', monospace;
  font-size: 0.76rem; letter-spacing: 0.08em;
  color: {MUTED}; padding: 0.45rem 1.1rem; border-radius: 8px;
  transition: all 0.18s ease;
}}
.stTabs [aria-selected="true"] {{
  background: {BORDER} !important; color: {ACCENT} !important;
}}

/* Metric cards */
[data-testid="metric-container"] {{
  background: {SURFACE}; border: 1px solid {BORDER};
  border-radius: 10px; padding: 0.85rem 1rem;
  box-shadow: 0 2px 16px rgba(0,0,0,0.35);
}}
[data-testid="metric-container"] label {{
  font-family: 'IBM Plex Mono', monospace;
  font-size: 0.67rem; letter-spacing: 0.12em;
  text-transform: uppercase; color: {MUTED};
}}
[data-testid="metric-container"] [data-testid="stMetricValue"] {{
  font-family: 'IBM Plex Mono', monospace;
  font-size: 1.35rem; font-weight: 700; color: {TEXT};
}}

/* Hero */
.atx-hero {{
  background: linear-gradient(135deg, rgba(9,15,28,0.98) 0%, rgba(15,26,43,0.96) 100%);
  border: 1px solid {BORDER}; border-radius: 16px;
  padding: 1.5rem 2rem; margin-bottom: 1.2rem; position: relative; overflow: hidden;
}}
.atx-hero::before {{
  content:''; position:absolute; top:-50px; left:-70px;
  width:320px; height:320px;
  background: radial-gradient(circle, rgba(34,211,238,0.10) 0%, transparent 70%);
  pointer-events: none;
}}
.atx-wordmark {{
  font-family: 'IBM Plex Mono', monospace;
  font-size: 0.7rem; letter-spacing: 0.24em;
  text-transform: uppercase; color: {ACCENT}; margin-bottom: 0.3rem;
}}
.atx-title {{
  font-family: 'Space Grotesk', sans-serif;
  font-size: 2.2rem; font-weight: 700; color: {TEXT};
  margin: 0 0 0.3rem 0; line-height: 1.15;
}}
.atx-title span {{ color: {ACCENT}; }}
.atx-sub {{
  color: {MUTED}; font-size: 0.9rem; line-height: 1.5;
}}
.atx-badge {{
  display: inline-block; font-family: 'IBM Plex Mono', monospace;
  font-size: 0.63rem; letter-spacing: 0.1em; text-transform: uppercase;
  background: rgba(34,211,238,0.09); color: {ACCENT};
  border: 1px solid rgba(34,211,238,0.22); border-radius: 20px;
  padding: 0.18rem 0.6rem; margin-right: 0.4rem; margin-top: 0.7rem;
}}

/* Signal pill */
.sig-pill {{
  display:inline-block; font-family:'IBM Plex Mono',monospace;
  font-size:1.1rem; font-weight:700; letter-spacing:0.05em;
  padding: 0.3rem 1.1rem; border-radius: 24px; margin:0.2rem 0;
}}
.sig-buy  {{ background:rgba(16,185,129,0.15); color:{BULL};  border:1px solid rgba(16,185,129,0.3); }}
.sig-sell {{ background:rgba(244,63,94,0.15);  color:{SELL_C}; border:1px solid rgba(244,63,94,0.3);  }}
.sig-hold {{ background:rgba(245,158,11,0.15); color:{GOLD};  border:1px solid rgba(245,158,11,0.3); }}

/* Section labels */
.sl {{
  font-family:'IBM Plex Mono',monospace;
  font-size:0.67rem; letter-spacing:0.18em;
  text-transform:uppercase; color:{MUTED};
  margin-bottom:0.5rem; margin-top:1.1rem;
}}

/* Strategy lab dark room */
.lab-header {{
  background: linear-gradient(135deg, #0a0012 0%, #12001a 100%);
  border: 1px solid rgba(167,139,250,0.25); border-radius: 12px;
  padding: 1rem 1.4rem; margin-bottom: 1rem;
}}
.lab-label {{
  font-family:'IBM Plex Mono',monospace; font-size:0.68rem;
  letter-spacing:0.2em; text-transform:uppercase;
  color:{PURPLE}; margin-bottom:0.3rem;
}}
.lab-title {{
  font-family:'Space Grotesk',sans-serif; font-size:1.4rem;
  font-weight:700; color:{TEXT};
}}

/* Buttons */
.stButton > button {{
  background: linear-gradient(135deg, {ACCENT} 0%, #0891b2 100%);
  color: #080d18; border:none; border-radius:8px;
  font-family:'IBM Plex Mono',monospace; font-size:0.82rem;
  font-weight:700; letter-spacing:0.06em;
  padding:0.55rem 1.4rem; transition:opacity 0.18s;
}}
.stButton > button:hover {{ opacity:0.86; }}
.stDownloadButton > button {{
  background:{SURFACE}; color:{TEXT};
  border:1px solid {BORDER}; border-radius:8px;
  font-family:'IBM Plex Mono',monospace; font-size:0.76rem;
  transition:border-color 0.18s;
}}
.stDownloadButton > button:hover {{ border-color:{ACCENT}; color:{ACCENT}; }}

/* Expanders */
details {{
  background:{SURFACE} !important; border:1px solid {BORDER} !important;
  border-radius:10px !important;
}}
/* DataFrames */
.stDataFrame {{ background:{SURFACE} !important; }}
/* Alerts */
.stAlert {{
  background:rgba(34,211,238,0.05) !important;
  border:1px solid rgba(34,211,238,0.18) !important;
  border-radius:10px !important;
}}
</style>
"""


def _inject_css():
    st.markdown(_CSS, unsafe_allow_html=True)


# ═══════════════════════════════════════════════════════════════════════════
# Plotly figure builders
# ═══════════════════════════════════════════════════════════════════════════

def _fig(**kw) -> go.Figure:
    f = go.Figure()
    f.update_layout(**{**PLOTLY_BASE, **kw})
    return f


def fig_candlestick(ohlcv: pd.DataFrame, signal: EnsembleSignal) -> go.Figure:
    """Candlestick with buy/sell markers and volume subplot."""
    df = ohlcv.copy()

    fig = make_subplots(
        rows=2, cols=1, shared_xaxes=True,
        vertical_spacing=0.04, row_heights=[0.72, 0.28],
        subplot_titles=(f"{signal.ticker}  ·  Price & Consensus Signals", "Volume"),
    )
    for ann in fig.layout.annotations:
        ann.font = dict(color=MUTED, size=11)

    fig.add_trace(go.Candlestick(
        x=df.index, open=df["open"], high=df["high"],
        low=df["low"], close=df["close"], name="Price",
        increasing_line_color=BULL, decreasing_line_color=SELL_C,
        increasing_fillcolor=BULL,  decreasing_fillcolor=SELL_C,
    ), row=1, col=1)

    # EMA overlays
    ema20 = df["close"].ewm(span=20, adjust=False).mean()
    ema50 = df["close"].ewm(span=50, adjust=False).mean()
    fig.add_trace(go.Scatter(x=df.index, y=ema20, name="EMA20",
        line=dict(color=ACCENT, width=1.4, dash="dot")), row=1, col=1)
    fig.add_trace(go.Scatter(x=df.index, y=ema50, name="EMA50",
        line=dict(color=GOLD, width=1.4, dash="dash")), row=1, col=1)

    # Volume bars
    vol_colors = [BULL if c >= o else SELL_C
                  for c, o in zip(df["close"], df["open"])]
    fig.add_trace(go.Bar(
        x=df.index, y=df["volume"], name="Volume",
        marker_color=vol_colors, opacity=0.6,
    ), row=2, col=1)

    fig.update_layout(
        **PLOTLY_BASE, height=680,
        title=dict(text=f"<b>{signal.ticker}</b>  ·  Price Structure",
                   font=dict(size=15, color=TEXT)),
        legend=dict(orientation="h", yanchor="bottom", y=1.02,
                    bgcolor="rgba(0,0,0,0)", font=dict(size=11)),
        xaxis_rangeslider_visible=False,
    )
    fig.update_yaxes(gridcolor="rgba(255,255,255,0.04)", zerolinecolor="rgba(255,255,255,0.08)")
    fig.update_xaxes(gridcolor="rgba(255,255,255,0.03)")
    return fig


def fig_signal_gauge(signal: EnsembleSignal) -> go.Figure:
    """Confidence gauge coloured by signal direction."""
    color = SIGNAL_COLOR.get(signal.final_signal, GOLD)
    fig = go.Figure(go.Indicator(
        mode="gauge+number",
        value=signal.confidence * 100,
        number={"suffix": "%", "font": {"size": 40, "color": color, "family": "IBM Plex Mono"}},
        title={"text": f"<b>{signal.final_signal}</b> · Confidence",
               "font": {"size": 15, "color": TEXT}},
        gauge={
            "axis": {"range": [0, 100], "tickcolor": MUTED, "tickfont": {"color": MUTED}},
            "bar":  {"color": color, "thickness": 0.22},
            "bgcolor": SURFACE, "borderwidth": 0,
            "steps": [
                {"range": [0,  50], "color": "#0f1a2b"},
                {"range": [50, 75], "color": "#111f30"},
                {"range": [75, 100], "color": "#0d2018"},
            ],
        },
    ))
    fig.update_layout(**PLOTLY_BASE, height=320)
    return fig


def fig_component_bar(signal: EnsembleSignal) -> go.Figure:
    """Weighted component scores bar chart."""
    comp_df = build_signal_component_df(signal)
    # Exclude ensemble row for clean bar chart
    comp_df = comp_df[comp_df["Component"] != "ENSEMBLE"]
    colors  = [BULL if s >= 0 else SELL_C for s in comp_df["Weighted Score"]]

    fig = _fig(height=300,
               title=dict(text="<b>Signal Component Weights</b>",
                          font=dict(size=13, color=TEXT)))
    fig.add_trace(go.Bar(
        x=comp_df["Component"], y=comp_df["Weighted Score"],
        marker_color=colors,
        text=[f"{s:.3f}" for s in comp_df["Weighted Score"]],
        textposition="outside",
        textfont=dict(color=TEXT, size=12),
        hovertemplate="%{x}<br>Score: %{y:.3f}<br>%{customdata}<extra></extra>",
        customdata=comp_df["Detail"],
    ))
    fig.add_hline(y=0, line_color="rgba(255,255,255,0.2)", line_width=1)
    fig.update_yaxes(title_text="Weighted Score", range=[-0.5, 0.5],
                     gridcolor="rgba(255,255,255,0.05)")
    return fig


def fig_equity_curve(result, strategy_label: str) -> go.Figure:
    """Equity curve vs buy-and-hold."""
    h = result.history
    fig = _fig(height=420,
               title=dict(text="<b>Strategy Equity vs Buy & Hold</b>",
                          font=dict(size=13, color=TEXT)))
    fig.add_trace(go.Scatter(
        x=h.index, y=h["benchmark_equity"], name="Buy & Hold",
        fill="tozeroy", fillcolor="rgba(90,122,154,0.07)",
        line=dict(color=MUTED, width=1.8, dash="dash"),
    ))
    fig.add_trace(go.Scatter(
        x=h.index, y=h["strategy_equity"], name=strategy_label,
        line=dict(color=GOLD, width=2.5),
    ))
    # Trade markers
    if "trade" in h.columns:
        buys  = h[h["trade"] > 0]
        sells = h[h["trade"] < 0]
        if not buys.empty:
            fig.add_trace(go.Scatter(
                x=buys.index, y=buys["strategy_equity"], name="Buy",
                mode="markers",
                marker=dict(symbol="triangle-up", size=10, color=BULL,
                            line=dict(color=BG, width=1)),
            ))
        if not sells.empty:
            fig.add_trace(go.Scatter(
                x=sells.index, y=sells["strategy_equity"], name="Sell",
                mode="markers",
                marker=dict(symbol="triangle-down", size=10, color=SELL_C,
                            line=dict(color=BG, width=1)),
            ))

    fig.update_yaxes(title_text="Portfolio Value ($)",
                     gridcolor="rgba(255,255,255,0.05)")
    fig.update_xaxes(title_text="Date")
    fig.update_layout(
        legend=dict(orientation="h", yanchor="bottom", y=1.02,
                    bgcolor="rgba(0,0,0,0)"))
    return fig


def fig_drawdown(result) -> go.Figure:
    h   = result.history
    fig = _fig(height=280,
               title=dict(text="<b>Drawdown (%)</b>", font=dict(size=13, color=TEXT)))
    fig.add_trace(go.Scatter(
        x=h.index, y=h["drawdown"] * 100, name="Drawdown",
        fill="tozeroy", fillcolor="rgba(244,63,94,0.12)",
        line=dict(color=SELL_C, width=2.0),
    ))
    fig.update_yaxes(title_text="Drawdown %", gridcolor="rgba(255,255,255,0.05)")
    return fig


def fig_monthly_heatmap(result) -> go.Figure:
    h       = result.history
    eq      = h["strategy_equity"]
    monthly = eq.resample("ME").last().pct_change().dropna() * 100
    mdf     = pd.DataFrame({
        "year":  monthly.index.year,
        "month": monthly.index.month,
        "ret":   monthly.values,
    })
    pivot  = mdf.pivot(index="year", columns="month", values="ret")
    labels = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
    cols   = [labels[c - 1] for c in pivot.columns]

    fig = go.Figure(go.Heatmap(
        z=pivot.values, x=cols, y=[str(y) for y in pivot.index],
        colorscale=[[0.0, SELL_C], [0.5, "#1a2d45"], [1.0, BULL]],
        zmid=0,
        text=[[f"{v:.1f}%" if not np.isnan(v) else "" for v in row] for row in pivot.values],
        texttemplate="%{text}", textfont=dict(size=10, color=TEXT),
        hovertemplate="Year %{y} · %{x}<br>Return: %{z:.2f}%<extra></extra>",
        colorbar=dict(title="Ret %", tickfont=dict(color=TEXT)),
    ))
    fig.update_layout(
        **PLOTLY_BASE,
        height=max(240, len(pivot) * 38 + 80),
        title=dict(text="<b>Monthly Return Heatmap</b>", font=dict(size=13, color=TEXT)),
    )
    return fig


def fig_forecast_chart(ohlcv: pd.DataFrame, fr: ForecastResult) -> go.Figure:
    """Recent price tail + tomorrow forecast band."""
    last30  = ohlcv.tail(40)
    fig     = _fig(height=380,
                   title=dict(text="<b>Price Forecast  ·  Tomorrow Scenario</b>",
                              font=dict(size=13, color=TEXT)))

    fig.add_trace(go.Scatter(
        x=last30.index, y=last30["close"],
        name="Close", line=dict(color=TEXT, width=2.0),
    ))

    # Forecast dashed line from last close → ensemble pred
    next_date  = last30.index[-1] + pd.Timedelta(days=1)
    last_close = float(last30["close"].iloc[-1])

    fig.add_trace(go.Scatter(
        x=[last30.index[-1], next_date],
        y=[last_close, fr.ensemble_pred],
        name="Ensemble Forecast",
        mode="lines+markers",
        line=dict(color=GOLD, width=2.2, dash="dot"),
        marker=dict(size=9, symbol="circle", color=GOLD),
    ))

    # Prophet line if available
    if fr.prophet_pred is not None:
        fig.add_trace(go.Scatter(
            x=[last30.index[-1], next_date],
            y=[last_close, fr.prophet_pred],
            name="Prophet",
            mode="lines+markers",
            line=dict(color=PURPLE, width=1.8, dash="dot"),
            marker=dict(size=7, symbol="diamond", color=PURPLE),
        ))

    # TimesFM line if available
    if fr.timesfm_pred is not None:
        fig.add_trace(go.Scatter(
            x=[last30.index[-1], next_date],
            y=[last_close, fr.timesfm_pred],
            name="TimesFM",
            mode="lines+markers",
            line=dict(color=ACCENT, width=1.8, dash="dot"),
            marker=dict(size=7, symbol="square", color=ACCENT),
        ))

    # Confidence band
    fig.add_trace(go.Scatter(
        x=[next_date, next_date],
        y=[fr.lower_bound, fr.upper_bound],
        name="±1σ Range",
        mode="markers",
        marker=dict(size=14, symbol="line-ns-open",
                    color=GOLD, line=dict(width=2, color=GOLD)),
    ))

    # Shade between lower/upper
    fig.add_trace(go.Scatter(
        x=[next_date, next_date],
        y=[fr.lower_bound, fr.upper_bound],
        fill="toself", fillcolor="rgba(245,158,11,0.10)",
        line=dict(color="rgba(0,0,0,0)"), showlegend=False, hoverinfo="skip",
    ))

    fig.update_yaxes(title_text="Price ($)", gridcolor="rgba(255,255,255,0.05)")
    fig.update_xaxes(title_text="Date")
    fig.update_layout(
        legend=dict(orientation="h", yanchor="bottom", y=1.02, bgcolor="rgba(0,0,0,0)"))
    return fig


def fig_rolling_sharpe(result) -> go.Figure:
    h       = result.history
    rets    = h["strategy_equity"].pct_change().dropna()
    w       = 30
    rs      = (rets.rolling(w).mean() / rets.rolling(w).std().clip(lower=1e-9)) * np.sqrt(252)
    pos     = rs.copy(); pos[pos < 0]  = np.nan
    neg     = rs.copy(); neg[neg >= 0] = np.nan

    fig = _fig(height=280,
               title=dict(text=f"<b>Rolling {w}-day Sharpe</b>",
                          font=dict(size=13, color=TEXT)))
    fig.add_trace(go.Scatter(x=rs.index, y=pos, name="Positive",
        fill="tozeroy", fillcolor="rgba(16,185,129,0.12)",
        line=dict(color=BULL, width=1.8)))
    fig.add_trace(go.Scatter(x=rs.index, y=neg, name="Negative",
        fill="tozeroy", fillcolor="rgba(244,63,94,0.12)",
        line=dict(color=SELL_C, width=1.8)))
    fig.add_hline(y=0, line_color="rgba(255,255,255,0.2)", line_width=1)
    fig.update_yaxes(title_text="Sharpe", gridcolor="rgba(255,255,255,0.05)")
    return fig


def fig_indicator_bar(ind_df: pd.DataFrame) -> go.Figure:
    """Horizontal bar of indicator values coloured by signal."""
    color_map = {BUY: BULL, SELL: SELL_C, NEUTRAL: MUTED}
    colors    = [color_map.get(s, MUTED) for s in ind_df["signal"]]

    fig = _fig(height=max(400, len(ind_df) * 22 + 60),
               title=dict(text="<b>Indicator Signal Panel</b>",
                          font=dict(size=13, color=TEXT)))
    fig.add_trace(go.Bar(
        x=ind_df["value"], y=ind_df["name"],
        orientation="h",
        marker_color=colors, opacity=0.82,
        hovertemplate="%{y}<br>Value: %{x:.4f}<extra></extra>",
    ))
    fig.update_xaxes(title_text="Value", gridcolor="rgba(255,255,255,0.05)")
    fig.update_yaxes(tickfont=dict(size=9))
    return fig


# ═══════════════════════════════════════════════════════════════════════════
# KPI card renderer
# ═══════════════════════════════════════════════════════════════════════════

def render_kpi_row(metrics: dict, label: str = "") -> None:
    cols = st.columns(8)
    kpis = [
        ("Total Return",     f"{metrics.get('Total Return', 0):.2%}",          metrics.get('Total Return', 0) >= 0),
        ("Ann. Return",      f"{metrics.get('Annualised Return', 0):.2%}",      metrics.get('Annualised Return', 0) >= 0),
        ("Sharpe",           f"{metrics.get('Sharpe Ratio', 0):.2f}",          metrics.get('Sharpe Ratio', 0) >= 1),
        ("Sortino",          f"{metrics.get('Sortino Ratio', 0):.2f}",          metrics.get('Sortino Ratio', 0) >= 1),
        ("Calmar",           f"{metrics.get('Calmar Ratio', 0):.2f}",           metrics.get('Calmar Ratio', 0) >= 0.5),
        ("Max Drawdown",     f"{metrics.get('Max Drawdown', 0):.2%}",           metrics.get('Max Drawdown', 0) >= 0),
        ("Ann. Vol",         f"{metrics.get('Annualised Volatility', 0):.2%}", True),
        ("# Trades",         f"{int(metrics.get('Number of Trades', 0))}",     True),
    ]
    for col, (name, val, positive) in zip(cols, kpis):
        col.metric(f"{label + ' · ' if label else ''}{name}", val,
                   delta=val, delta_color="normal" if positive else "inverse")


# ═══════════════════════════════════════════════════════════════════════════
# Sidebar
# ═══════════════════════════════════════════════════════════════════════════

def render_sidebar() -> dict[str, Any]:
    default_end   = date.today()
    default_start = default_end - timedelta(days=365 * 2)
    strategy_list = list_strategies()

    with st.sidebar:
        st.markdown('<div style="font-family:IBM Plex Mono;font-size:0.7rem;'
                    'letter-spacing:0.2em;text-transform:uppercase;'
                    f'color:{ACCENT};margin-bottom:0.8rem;">⬡ AlgoTradeX</div>',
                    unsafe_allow_html=True)

        st.markdown(f'<div style="font-family:IBM Plex Mono;font-size:0.68rem;'
                    f'letter-spacing:0.14em;text-transform:uppercase;'
                    f'color:{MUTED};border-bottom:1px solid {BORDER};'
                    f'padding-bottom:0.3rem;margin-bottom:0.6rem;">📡 Data Source</div>',
                    unsafe_allow_html=True)

        uploaded = st.file_uploader("Upload OHLCV CSV", type=["csv"])
        ticker   = st.text_input("Ticker Symbol", value="AAPL",
                                 help="Yahoo Finance ticker (e.g. AAPL, RELIANCE.NS)")

        date_range = st.date_input(
            "Date Range",
            value=(default_start, default_end),
            min_value=date(2000, 1, 1), max_value=default_end,
        )

        st.markdown(f'<div style="font-family:IBM Plex Mono;font-size:0.68rem;'
                    f'letter-spacing:0.14em;text-transform:uppercase;'
                    f'color:{MUTED};border-bottom:1px solid {BORDER};'
                    f'padding-bottom:0.3rem;margin-top:1rem;margin-bottom:0.6rem;">⚙️ Strategy Lab</div>',
                    unsafe_allow_html=True)

        strategy_labels = [s["label"] for s in strategy_list]
        strategy_keys   = {s["label"]: s["key"] for s in strategy_list}
        sel_label       = st.selectbox("Benchmark Strategy", strategy_labels)
        sel_key         = strategy_keys[sel_label]
        default_params  = STRATEGY_REGISTRY[sel_key]["params"]

        strategy_params: dict[str, Any] = {}
        if default_params:
            with st.expander("🎛️ Strategy Parameters", expanded=True):
                for k, v in default_params.items():
                    if isinstance(v, int):
                        strategy_params[k] = st.number_input(
                            k.replace("_", " ").title(),
                            min_value=1, max_value=500, value=v, step=1)
                    elif isinstance(v, float):
                        strategy_params[k] = st.number_input(
                            k.replace("_", " ").title(),
                            min_value=1.0, max_value=100.0, value=v, step=1.0)

        st.markdown(f'<div style="font-family:IBM Plex Mono;font-size:0.68rem;'
                    f'letter-spacing:0.14em;text-transform:uppercase;'
                    f'color:{MUTED};border-bottom:1px solid {BORDER};'
                    f'padding-bottom:0.3rem;margin-top:1rem;margin-bottom:0.6rem;">💼 Portfolio</div>',
                    unsafe_allow_html=True)

        initial_capital  = st.number_input("Initial Capital ($)",
            min_value=1_000.0, max_value=10_000_000.0, value=100_000.0, step=5_000.0)
        transaction_cost = st.number_input("Transaction Cost",
            min_value=0.0, max_value=0.02, value=0.001, step=0.0001, format="%.4f")
        slippage_pct     = st.number_input("Slippage",
            min_value=0.0, max_value=0.02, value=0.0005, step=0.0001, format="%.4f")

        st.markdown(f'<div style="font-family:IBM Plex Mono;font-size:0.68rem;'
                    f'letter-spacing:0.14em;text-transform:uppercase;'
                    f'color:{MUTED};border-bottom:1px solid {BORDER};'
                    f'padding-bottom:0.3rem;margin-top:1rem;margin-bottom:0.6rem;">🔮 Forecast</div>',
                    unsafe_allow_html=True)

        use_prophet  = st.checkbox("Enable Prophet", value=True)
        use_timesfm  = st.checkbox("Enable TimesFM", value=False,
                                   help="Requires: pip install timesfm  (downloads 200M model)")

        st.markdown("---")
        run_clicked = st.button("▶  Analyse", type="primary", use_container_width=True)

    if len(date_range) != 2:
        raise ValueError("Select both a start and end date.")

    return {
        "ticker":           ticker.strip().upper() or "AAPL",
        "uploaded":         uploaded,
        "start_date":       date_range[0],
        "end_date":         date_range[1],
        "strategy_key":     sel_key,
        "strategy_label":   sel_label,
        "strategy_params":  strategy_params,
        "initial_capital":  float(initial_capital),
        "transaction_cost": float(transaction_cost),
        "slippage_pct":     float(slippage_pct),
        "use_prophet":      use_prophet,
        "use_timesfm":      use_timesfm,
        "run_clicked":      run_clicked,
    }


# ═══════════════════════════════════════════════════════════════════════════
# Analysis pipeline  (pure computation, no st.* calls inside)
# ═══════════════════════════════════════════════════════════════════════════

def run_analysis(inputs: dict, progress_cb) -> dict:
    # 1. Data
    progress_cb("📡 Fetching market data …")
    if inputs["uploaded"]:
        ohlcv_full = load_csv_upload(inputs["uploaded"])
    else:
        ohlcv_full = fetch_yfinance(
            inputs["ticker"], inputs["start_date"], inputs["end_date"])

    ohlcv = slice_date_range(ohlcv_full, inputs["start_date"], inputs["end_date"])
    validate_ohlcv(ohlcv)

    # 2. Technical + Ensemble signal
    progress_cb("📊 Computing 26 indicators & ensemble signal …")
    signal = compute_ensemble_signal(
        ticker=inputs["ticker"],
        ohlcv=ohlcv,
        news_headlines=None,     # live headlines can be injected here
        forecast_price=None,     # updated after forecasting below
    )

    # 3. Forecast
    progress_cb("🔮 Running price forecast (Prophet / TimesFM) …")
    forecast = run_forecast(
        ohlcv["close"],
        horizon=1,
        use_prophet=inputs["use_prophet"],
        use_timesfm=inputs["use_timesfm"],
    )

    # 4. Re-compute ensemble with forecast price
    progress_cb("🧠 Finalising ensemble signal …")
    signal = compute_ensemble_signal(
        ticker=inputs["ticker"],
        ohlcv=ohlcv,
        news_headlines=None,
        forecast_price=forecast.ensemble_pred,
    )

    # 5. Backtesting
    progress_cb(f"⚡ Backtesting {inputs['strategy_label']} …")
    backtest = run_named_strategy(
        ohlcv=ohlcv_full,
        strategy_key=inputs["strategy_key"],
        params=inputs["strategy_params"],
        initial_capital=inputs["initial_capital"],
        transaction_cost=inputs["transaction_cost"],
        slippage_pct=inputs["slippage_pct"],
        start_date=inputs["start_date"],
        end_date=inputs["end_date"],
    )

    # 6. Indicator table for panel
    from strategies.algotradex_strategies import run_all_indicators, build_summary_table
    ind_results = run_all_indicators(ohlcv)
    ind_df      = build_summary_table(ind_results)

    return {
        "ticker":      inputs["ticker"],
        "ohlcv":       ohlcv,
        "signal":      signal,
        "forecast":    forecast,
        "backtest":    backtest,
        "ind_df":      ind_df,
        "inputs":      inputs,
    }


# ═══════════════════════════════════════════════════════════════════════════
# Tab renderers
# ═══════════════════════════════════════════════════════════════════════════

def tab_command_deck(r: dict) -> None:
    signal   = r["signal"]
    forecast = r["forecast"]
    ohlcv    = r["ohlcv"]

    # Signal pill
    pill_class = {"Buy": "sig-buy", "Sell": "sig-sell"}.get(signal.final_signal, "sig-hold")
    st.markdown(
        f"<div class='sl'>Consensus Final Signal</div>"
        f"<div class='sig-pill {pill_class}'>{signal.final_signal}</div>",
        unsafe_allow_html=True,
    )

    # Top KPI strip
    c1, c2, c3, c4, c5 = st.columns(5)
    last_price = float(ohlcv["close"].iloc[-1])
    prev_price = float(ohlcv["close"].iloc[-2]) if len(ohlcv) > 1 else last_price
    day_chg    = (last_price - prev_price) / prev_price

    c1.metric("Last Close",   f"${last_price:.2f}", f"{day_chg:+.2%}")
    c2.metric("Signal Score", f"{signal.ensemble_score:+.3f}")
    c3.metric("Confidence",   f"{signal.confidence:.0%}")
    c4.metric("Forecast",     f"${forecast.ensemble_pred:.2f}",
              f"{forecast.expected_return_pct:+.2%}")
    c5.metric("Forecast Band",
              f"${forecast.lower_bound:.2f} – ${forecast.upper_bound:.2f}")

    # Technical tally
    st.markdown("<div class='sl'>Technical Indicator Tally</div>", unsafe_allow_html=True)
    ta1, ta2, ta3, ta4 = st.columns(4)
    ta1.metric("Buy",     signal.buy_count,     delta=f"/{signal.total_indicators}")
    ta2.metric("Sell",    signal.sell_count,    delta=f"/{signal.total_indicators}")
    ta3.metric("Neutral", signal.neutral_count, delta=f"/{signal.total_indicators}")
    ta4.metric("Total Indicators", signal.total_indicators)

    # Gauge + Component bar side by side
    col_g, col_b = st.columns([1, 1.6])
    with col_g:
        st.plotly_chart(fig_signal_gauge(signal), use_container_width=True)
    with col_b:
        st.plotly_chart(fig_component_bar(signal), use_container_width=True)

    # Component detail table
    with st.expander("Signal Component Detail", expanded=False):
        comp_df = build_signal_component_df(signal)
        st.dataframe(comp_df, use_container_width=True, hide_index=True)

    st.info(
        f"**{signal.final_signal} signal** with {signal.confidence:.0%} confidence. "
        f"Ensemble score {signal.ensemble_score:+.3f}. "
        f"Forecast: **${forecast.ensemble_pred:.2f}** "
        f"(range ${forecast.lower_bound:.2f} – ${forecast.upper_bound:.2f}). "
        f"Methods: {', '.join(forecast.methods_used)}."
    )


def tab_chart(r: dict) -> None:
    st.plotly_chart(fig_candlestick(r["ohlcv"], r["signal"]),
                    use_container_width=True)


def tab_strategy_lab(r: dict) -> None:
    bt      = r["backtest"]
    inputs  = r["inputs"]

    # Dark-room header
    st.markdown(f"""
<div class="lab-header">
  <div class="lab-label">⬡ Strategy Laboratory  ·  Backtesting Sandbox</div>
  <div class="lab-title">{bt.strategy_name}</div>
  <div style="color:{MUTED};font-size:0.82rem;margin-top:0.3rem;">
    Simulated data only — not live trading
  </div>
</div>
""", unsafe_allow_html=True)

    # Performance Dossier KPIs
    st.markdown("<div class='sl'>Performance Dossier</div>", unsafe_allow_html=True)
    render_kpi_row(bt.metrics, bt.strategy_name)

    # Equity curve + Drawdown
    st.plotly_chart(fig_equity_curve(bt, bt.strategy_name), use_container_width=True)

    col_dd, col_rs = st.columns(2)
    with col_dd:
        st.plotly_chart(fig_drawdown(bt), use_container_width=True)
    with col_rs:
        st.plotly_chart(fig_rolling_sharpe(bt), use_container_width=True)

    # Monthly heatmap
    st.plotly_chart(fig_monthly_heatmap(bt), use_container_width=True)

    # Trade log
    if not bt.trade_log.empty:
        st.markdown("<div class='sl'>Trade Log</div>", unsafe_allow_html=True)
        wins  = bt.trade_log[bt.trade_log.get("pnl", pd.Series(0)) > 0] if "pnl" in bt.trade_log.columns else pd.DataFrame()
        total_trades = len(bt.trade_log[bt.trade_log["direction"] == "Sell"]) if "direction" in bt.trade_log.columns else 0
        w1, w2, w3 = st.columns(3)
        if total_trades > 0 and len(wins) > 0:
            w1.metric("Win Rate", f"{len(wins) / total_trades:.0%}")
        w2.metric("Total Trades", f"{total_trades}")
        if "cost" in bt.trade_log.columns:
            w3.metric("Total Costs", f"${bt.trade_log['cost'].sum():,.2f}")

        with st.expander("📋 Full Trade Log", expanded=False):
            st.dataframe(bt.trade_log, use_container_width=True, hide_index=True)

    # Strategy params summary
    with st.expander("⚙️ Experiment Configuration", expanded=False):
        cfg = {
            "Strategy":         bt.strategy_name,
            "Initial Capital":  f"${inputs['initial_capital']:,.0f}",
            "Transaction Cost": f"{inputs['transaction_cost']:.3%}",
            "Slippage":         f"{inputs['slippage_pct']:.4%}",
            **{k: v for k, v in inputs["strategy_params"].items()},
        }
        st.json(cfg)


def tab_forecast(r: dict) -> None:
    forecast = r["forecast"]
    ohlcv    = r["ohlcv"]

    st.warning(
        "⚠️ **Probabilistic scenario — not a trading signal or guarantee.** "
        "Forecasts use time-series models and are for research purposes only."
    )

    # Summary cards
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Last Close",        f"${forecast.last_close:.2f}")
    c2.metric("Ensemble Forecast", f"${forecast.ensemble_pred:.2f}",
              f"{forecast.expected_return_pct:+.2%}")
    c3.metric("Lower Bound",       f"${forecast.lower_bound:.2f}")
    c4.metric("Upper Bound",       f"${forecast.upper_bound:.2f}")

    # Model breakdown
    st.markdown("<div class='sl'>Model Breakdown</div>", unsafe_allow_html=True)
    model_cols = st.columns(3)
    model_cols[0].metric("Prophet",    f"${forecast.prophet_pred:.2f}" if forecast.prophet_pred else "Not available")
    model_cols[1].metric("TimesFM",    f"${forecast.timesfm_pred:.2f}" if forecast.timesfm_pred else "Not available")
    model_cols[2].metric("Naive (linear)", f"${forecast.naive_pred:.2f}")

    st.plotly_chart(fig_forecast_chart(ohlcv, forecast), use_container_width=True)

    with st.expander("Forecast Methodology", expanded=False):
        st.markdown(f"""
#### Ensemble Composition
- **Meta Prophet** (45% weight when available): Captures yearly + weekly seasonality
  using a Bayesian additive regression model. `seasonality_mode=multiplicative`,
  `changepoint_prior_scale=0.08`.
- **Google TimesFM** (45% weight when available): Zero-shot 200M-parameter
  foundation model. No fine-tuning. Context window: 128 bars.
- **Naive linear** (10% floor / 100% fallback): OLS linear extrapolation
  over the last 30 bars.

#### Confidence Bounds
`±1σ` computed from the 20-day rolling standard deviation of daily returns.
Range = `ensemble_pred × (1 ± σ)`.

Methods used for this run: **{', '.join(forecast.methods_used)}**
""")


def tab_indicator_panel(r: dict) -> None:
    ind_df = r["ind_df"]
    signal = r["signal"]

    st.markdown("<div class='sl'>All 26 Indicators — Current Signal</div>",
                unsafe_allow_html=True)

    # Summary pills
    p1, p2, p3 = st.columns(3)
    p1.metric(f"🟢 Buy",     signal.buy_count)
    p2.metric(f"🔴 Sell",    signal.sell_count)
    p3.metric(f"⚪ Neutral", signal.neutral_count)

    # Filter controls
    flt = st.selectbox("Filter by Signal", ["All", "Buy", "Sell", "Neutral"])
    disp_df = ind_df if flt == "All" else ind_df[ind_df["signal"] == flt]

    st.plotly_chart(fig_indicator_bar(disp_df), use_container_width=True)

    with st.expander("📋 Full Indicator Table", expanded=True):
        # Style the signal column
        def colour_signal(val: str) -> str:
            colours = {"Buy": f"color: {BULL}", "Sell": f"color: {SELL_C}",
                       "Neutral": f"color: {MUTED}"}
            return colours.get(val, "")

        styled = disp_df.style.applymap(colour_signal, subset=["signal"])
        st.dataframe(styled, use_container_width=True, hide_index=True)


def tab_raw_data(r: dict) -> None:
    ohlcv   = r["ohlcv"]
    bt      = r["backtest"]
    ticker  = r["ticker"]

    st.markdown("<div class='sl'>Downloads</div>", unsafe_allow_html=True)
    c1, c2, c3 = st.columns(3)
    c1.download_button("⬇ Market Data CSV",
        data=ohlcv.to_csv().encode(), mime="text/csv",
        file_name=f"{ticker.lower()}_market_data.csv", use_container_width=True)
    c2.download_button("⬇ Strategy Frame",
        data=bt.history.to_csv().encode(), mime="text/csv",
        file_name=f"{ticker.lower()}_{r['inputs']['strategy_key']}_backtest.csv",
        use_container_width=True)
    c3.download_button("⬇ Indicator Table",
        data=r["ind_df"].to_csv(index=False).encode(), mime="text/csv",
        file_name=f"{ticker.lower()}_indicators.csv", use_container_width=True)

    with st.expander("📊 Market Data", expanded=False):
        st.dataframe(ohlcv.tail(100), use_container_width=True)
    with st.expander("📋 Strategy Backtest History", expanded=False):
        st.dataframe(bt.history.tail(100), use_container_width=True)
    with st.expander("📋 Trade Log", expanded=False):
        if not bt.trade_log.empty:
            st.dataframe(bt.trade_log, use_container_width=True, hide_index=True)
        else:
            st.info("No trades executed in this period.")


# ═══════════════════════════════════════════════════════════════════════════
# Main entry point
# ═══════════════════════════════════════════════════════════════════════════

def main() -> None:
    st.set_page_config(
        page_title="AlgoTradeX · AI Trading Studio",
        layout="wide",
        page_icon="⚡",
        initial_sidebar_state="expanded",
    )
    _inject_css()

    # Hero header
    st.markdown("""
<div class="atx-hero">
  <div class="atx-wordmark">⬡ AlgoTradeX · AI Trading Studio</div>
  <h1 class="atx-title">Ensemble <span>Signal</span> Engine</h1>
  <p class="atx-sub">
    26 technical indicators · Prophet & TimesFM forecasting ·
    Weighted consensus signal · Strategy backtesting with full performance analytics
  </p>
  <div>
    <span class="atx-badge">Technical: 40%</span>
    <span class="atx-badge">Sentiment: 30%</span>
    <span class="atx-badge">Forecast: 30%</span>
    <span class="atx-badge">Prophet + TimesFM</span>
    <span class="atx-badge">VADER Sentiment</span>
  </div>
</div>
""", unsafe_allow_html=True)

    # Session state
    st.session_state.setdefault("result", None)
    st.session_state.setdefault("error", None)

    try:
        inputs = render_sidebar()
    except Exception as e:
        st.error(f"⚠️ Configuration error: {e}")
        return

    # Run analysis on button click or first load
    if inputs["run_clicked"] or st.session_state["result"] is None:
        _holder = st.empty()
        try:
            with st.spinner(""):
                result = run_analysis(
                    inputs,
                    progress_cb=lambda msg: _holder.info(msg),
                )
            st.session_state["result"] = result
            st.session_state["error"]  = None
        except Exception as e:
            st.session_state["error"]  = str(e)
        finally:
            _holder.empty()

    if st.session_state["error"]:
        st.error(f"❌ {st.session_state['error']}")

    if st.session_state["result"] is None:
        # Empty state
        st.markdown(f"""
<div style="text-align:center;padding:5rem 2rem;color:{MUTED};
            font-family:'IBM Plex Mono',monospace;">
  <div style="font-size:3rem;margin-bottom:1rem;">⚡</div>
  <div style="font-size:1.05rem;font-weight:600;color:{TEXT};margin-bottom:0.5rem;">
    Ready to Analyse
  </div>
  <div style="font-size:0.84rem;max-width:400px;margin:auto;line-height:1.7;">
    Enter a ticker and date range in the sidebar,<br>
    then press <strong style="color:{ACCENT}">▶ Analyse</strong>.
  </div>
</div>
""", unsafe_allow_html=True)
        return

    r = st.session_state["result"]

    tabs = st.tabs([
        "⚡ Command Deck",
        "🕯️ Chart",
        "🧪 Strategy Lab",
        "🔮 Forecast",
        "📊 Indicators",
        "🗂️ Raw Data",
    ])

    with tabs[0]: tab_command_deck(r)
    with tabs[1]: tab_chart(r)
    with tabs[2]: tab_strategy_lab(r)
    with tabs[3]: tab_forecast(r)
    with tabs[4]: tab_indicator_panel(r)
    with tabs[5]: tab_raw_data(r)


if __name__ == "__main__":
    main()
