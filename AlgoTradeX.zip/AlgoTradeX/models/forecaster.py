"""
forecaster.py
=============
Ensemble Forecasting Engine for AlgoTradeX.

Models
------
1. Meta Prophet  — handles seasonality (weekly/yearly) + holiday effects
2. Google TimesFM — zero-shot time-series foundation model
3. Naive Baseline — linear extrapolation (always available as fallback)

Ensemble Output
---------------
Price Prediction Range = weighted average of available model outputs.

  If both Prophet and TimesFM are available:
      forecast = 0.50 * prophet_pred + 0.50 * timesfm_pred

  If only one is available:
      forecast = that model's output

  Always: lower_bound, upper_bound computed from ±1σ of recent returns.

Mathematical note on TimesFM:
  TimesFM is a 200M-parameter decoder-only foundation model trained by Google
  on 100B time-series data points. It performs zero-shot forecasting —
  no fine-tuning is required. We feed the last `context_len` close prices
  (default 128) and request a 1-step forecast.
"""

from __future__ import annotations

import warnings
from dataclasses import dataclass
from typing import Tuple

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")


# ---------------------------------------------------------------------------
# Result container
# ---------------------------------------------------------------------------

@dataclass
class ForecastResult:
    last_close: float
    prophet_pred: float | None
    timesfm_pred: float | None
    naive_pred: float
    ensemble_pred: float          # the number we ship to the UI
    lower_bound: float
    upper_bound: float
    horizon_days: int
    methods_used: list[str]

    @property
    def expected_return_pct(self) -> float:
        return (self.ensemble_pred - self.last_close) / max(abs(self.last_close), 1e-8)

    def summary(self) -> dict:
        return {
            "Last Close":       round(self.last_close, 2),
            "Prophet":          round(self.prophet_pred, 2) if self.prophet_pred else "N/A",
            "TimesFM":          round(self.timesfm_pred, 2) if self.timesfm_pred else "N/A",
            "Naive (linear)":   round(self.naive_pred, 2),
            "Ensemble Forecast":round(self.ensemble_pred, 2),
            "Lower Bound":      round(self.lower_bound, 2),
            "Upper Bound":      round(self.upper_bound, 2),
            "Expected Move":    f"{self.expected_return_pct:.2%}",
            "Methods Used":     ", ".join(self.methods_used),
        }


# ---------------------------------------------------------------------------
# Naive baseline (always available)
# ---------------------------------------------------------------------------

def _naive_forecast(close: pd.Series, horizon: int = 1) -> float:
    """Linear-regression extrapolation over last 30 bars."""
    tail = close.tail(30).values
    x    = np.arange(len(tail), dtype=float)
    coef = np.polyfit(x, tail, 1)                     # slope, intercept
    return float(coef[0] * (len(tail) - 1 + horizon) + coef[1])


# ---------------------------------------------------------------------------
# Prophet model
# ---------------------------------------------------------------------------

def _run_prophet(close: pd.Series, horizon: int = 1) -> float | None:
    """
    Fit Meta Prophet on daily closes.

    Seasonality modes:
      yearly  : captures annual patterns (earnings cycles, seasonal demand)
      weekly  : captures Mon–Fri drift effects

    Returns predicted close `horizon` trading days ahead.
    Returns None if Prophet is not installed or fitting fails.
    """
    try:
        from prophet import Prophet  # type: ignore

        df = pd.DataFrame({
            "ds": close.index,
            "y":  close.values,
        })
        df["ds"] = pd.to_datetime(df["ds"])
        df = df.dropna()

        if len(df) < 30:
            return None

        m = Prophet(
            yearly_seasonality=True,
            weekly_seasonality=True,
            daily_seasonality=False,
            seasonality_mode="multiplicative",
            interval_width=0.80,
            changepoint_prior_scale=0.08,
        )
        m.fit(df, algorithm="LBFGS")

        future = m.make_future_dataframe(periods=horizon, freq="B")   # B = business days
        forecast = m.predict(future)
        pred_value = float(forecast["yhat"].iloc[-1])

        # Clip extreme predictions to ±15% of last close
        last = float(close.iloc[-1])
        pred_value = float(np.clip(pred_value, last * 0.85, last * 1.15))
        return pred_value

    except ImportError:
        return None
    except Exception:
        return None


# ---------------------------------------------------------------------------
# TimesFM model
# ---------------------------------------------------------------------------

def _run_timesfm(close: pd.Series, context_len: int = 128) -> float | None:
    """
    Zero-shot forecast using Google TimesFM.

    TimesFM expects a context window of time-series values.
    We pass the last `context_len` closing prices as a single time-series.
    The model returns a 10-step forecast; we take step[0] as "tomorrow."

    Returns None if timesfm is not installed or inference fails.
    """
    try:
        import timesfm  # type: ignore

        # Use last context_len prices
        context = close.tail(context_len).values.tolist()

        tfm = timesfm.TimesFm(
            context_len=context_len,
            horizon_len=10,
            input_patch_len=32,
            output_patch_len=128,
            num_layers=20,
            model_dims=1280,
            backend="cpu",           # change to "gpu" if CUDA is available
        )
        tfm.load_from_checkpoint(repo_id="google/timesfm-1.0-200m")

        # Batch of 1 time-series
        forecast_input = [context]
        point_forecast, _ = tfm.forecast(forecast_input, freq=[0])   # freq=0 = daily

        pred_value = float(point_forecast[0][0])                       # first step

        # Sanity clip ±20%
        last = float(close.iloc[-1])
        pred_value = float(np.clip(pred_value, last * 0.80, last * 1.20))
        return pred_value

    except ImportError:
        return None
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Ensemble combiner
# ---------------------------------------------------------------------------

def _compute_bounds(close: pd.Series, ensemble_pred: float) -> Tuple[float, float]:
    """Lower / upper bounds from ±1σ of 20-day daily returns."""
    returns = close.pct_change().dropna().tail(20)
    vol     = float(returns.std()) if len(returns) >= 2 else 0.015
    last    = float(close.iloc[-1])
    width   = max(vol, 0.005)
    return float(ensemble_pred * (1 - width)), float(ensemble_pred * (1 + width))


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def run_forecast(
    close: pd.Series,
    horizon: int = 1,
    use_prophet: bool = True,
    use_timesfm: bool = True,
    context_len: int = 128,
) -> ForecastResult:
    """
    Generate an ensemble price forecast.

    Parameters
    ----------
    close       : pd.Series of daily closing prices (DatetimeIndex)
    horizon     : Forecast horizon in trading days (default 1 = tomorrow)
    use_prophet : Attempt to run Prophet (skipped if not installed)
    use_timesfm : Attempt to run TimesFM  (skipped if not installed)
    context_len : TimesFM context window length

    Returns
    -------
    ForecastResult containing ensemble prediction and confidence bounds
    """
    last_close   = float(close.iloc[-1])
    naive_pred   = _naive_forecast(close, horizon)
    methods_used = ["Naive (linear)"]

    prophet_pred: float | None = None
    timesfm_pred: float | None = None

    if use_prophet:
        prophet_pred = _run_prophet(close, horizon)
        if prophet_pred is not None:
            methods_used.append("Prophet")

    if use_timesfm:
        timesfm_pred = _run_timesfm(close, context_len)
        if timesfm_pred is not None:
            methods_used.append("TimesFM")

    # Weighted ensemble
    valid_preds = []
    weights     = []

    if prophet_pred is not None:
        valid_preds.append(prophet_pred)
        weights.append(0.45)
    if timesfm_pred is not None:
        valid_preds.append(timesfm_pred)
        weights.append(0.45)

    # Naive always contributes if no deep models available
    if not valid_preds:
        ensemble_pred = naive_pred
    else:
        # Normalise weights and blend with naive at 10%
        total_w = sum(weights)
        ensemble_pred = float(
            sum(p * w / total_w * 0.90 for p, w in zip(valid_preds, weights))
            + naive_pred * 0.10
        )

    lower_bound, upper_bound = _compute_bounds(close, ensemble_pred)

    return ForecastResult(
        last_close=last_close,
        prophet_pred=prophet_pred,
        timesfm_pred=timesfm_pred,
        naive_pred=naive_pred,
        ensemble_pred=ensemble_pred,
        lower_bound=lower_bound,
        upper_bound=upper_bound,
        horizon_days=horizon,
        methods_used=methods_used,
    )
