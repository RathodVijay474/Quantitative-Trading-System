"""
signal_engine.py
================
Ensemble Signal Aggregator for AlgoTradeX.

Architecture:
  - Runs all technical indicators from algotradex_strategies.py
  - Collects sentiment score (VADER) and applies simple NLP scoring
  - Applies a 3-component weighted voting system:
      Technical Indicators : 40% weight
      Market Sentiment      : 30% weight
      Forecasting Model     : 30% weight
  - Outputs a Majority Consensus Final Signal with confidence score

Mathematical logic:
  Let S_tech, S_sent, S_fore ∈ {-1, 0, +1} be the directional scores.
  Ensemble = 0.40 * S_tech + 0.30 * S_sent + 0.30 * S_fore
  If Ensemble > 0.15  → Buy
  If Ensemble < -0.15 → Sell
  Else                → Hold
"""

from __future__ import annotations

import warnings
from dataclasses import dataclass, field
from typing import Any

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")

# ---------------------------------------------------------------------------
# Signal constants
# ---------------------------------------------------------------------------
BUY     = "Buy"
SELL    = "Sell"
NEUTRAL = "Neutral"

# Ensemble weights (must sum to 1.0)
W_TECH = 0.40
W_SENT = 0.30
W_FORE = 0.30


# ---------------------------------------------------------------------------
# Data containers
# ---------------------------------------------------------------------------

@dataclass
class ComponentScore:
    name: str
    raw_score: float          # -1 to +1
    signal: str               # Buy / Sell / Neutral
    weight: float
    detail: str
    sub_signals: dict[str, Any] = field(default_factory=dict)

    def weighted_score(self) -> float:
        return self.raw_score * self.weight


@dataclass
class EnsembleSignal:
    ticker: str
    timestamp: str
    final_signal: str
    confidence: float           # 0.0 – 1.0
    ensemble_score: float       # -1.0 – 1.0
    components: list[ComponentScore]

    # Breakdowns
    buy_count: int = 0
    sell_count: int = 0
    neutral_count: int = 0
    total_indicators: int = 0

    def to_summary_dict(self) -> dict:
        return {
            "ticker":         self.ticker,
            "timestamp":      self.timestamp,
            "final_signal":   self.final_signal,
            "confidence":     round(self.confidence, 4),
            "ensemble_score": round(self.ensemble_score, 4),
            "buy_count":      self.buy_count,
            "sell_count":     self.sell_count,
            "neutral_count":  self.neutral_count,
            "total":          self.total_indicators,
        }


# ---------------------------------------------------------------------------
# Technical component  (40%)
# ---------------------------------------------------------------------------

def _compute_technical_score(ohlcv: pd.DataFrame) -> ComponentScore:
    """
    Run all 26 indicators. Tally Buy/Sell/Neutral.
    Score = (buy - sell) / total ∈ [-1, +1]
    """
    try:
        from strategies.algotradex_strategies import run_all_indicators, build_signal_summary
        results = run_all_indicators(ohlcv)
        summary = build_signal_summary(results)

        buy_n  = summary["buy_count"]
        sell_n = summary["sell_count"]
        neu_n  = summary["neutral_count"]
        total  = summary["total"] or 1

        raw_score = (buy_n - sell_n) / total          # normalized -1..+1
        overall   = summary["overall"]

        if overall in ("Strong Buy", "Buy"):
            sig = BUY
        elif overall in ("Strong Sell", "Sell"):
            sig = SELL
        else:
            sig = NEUTRAL

        return ComponentScore(
            name="Technical Indicators",
            raw_score=float(raw_score),
            signal=sig,
            weight=W_TECH,
            detail=f"{buy_n}B / {sell_n}S / {neu_n}N across {total} indicators",
            sub_signals={
                "summary":       summary,
                "buy_count":     buy_n,
                "sell_count":    sell_n,
                "neutral_count": neu_n,
                "total":         total,
            },
        )
    except Exception as exc:
        return ComponentScore(
            name="Technical Indicators",
            raw_score=0.0,
            signal=NEUTRAL,
            weight=W_TECH,
            detail=f"Error: {exc}",
        )


# ---------------------------------------------------------------------------
# Sentiment component  (30%)
# ---------------------------------------------------------------------------

def _compute_sentiment_score(ticker: str, news_headlines: list[str] | None = None) -> ComponentScore:
    """
    Score sentiment using VADER.
    Falls back to 0.0 (neutral) if vaderSentiment is not installed
    or no headlines are supplied.

    compound ∈ [-1, +1] → directly used as raw_score.
    """
    try:
        from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
        analyzer = SentimentIntensityAnalyzer()

        if not news_headlines:
            # Synthetic neutral signal — no headlines available
            return ComponentScore(
                name="Market Sentiment",
                raw_score=0.0,
                signal=NEUTRAL,
                weight=W_SENT,
                detail="No headlines provided — sentiment neutral",
            )

        scores = [analyzer.polarity_scores(h)["compound"] for h in news_headlines]
        avg_compound = float(np.mean(scores))

        if avg_compound >= 0.05:
            sig = BUY
        elif avg_compound <= -0.05:
            sig = SELL
        else:
            sig = NEUTRAL

        detail = (
            f"Avg compound={avg_compound:.3f} "
            f"across {len(news_headlines)} headlines"
        )
        return ComponentScore(
            name="Market Sentiment",
            raw_score=avg_compound,
            signal=sig,
            weight=W_SENT,
            detail=detail,
            sub_signals={"headlines": news_headlines, "scores": scores},
        )

    except ImportError:
        return ComponentScore(
            name="Market Sentiment",
            raw_score=0.0,
            signal=NEUTRAL,
            weight=W_SENT,
            detail="vaderSentiment not installed — install with: pip install vaderSentiment",
        )


# ---------------------------------------------------------------------------
# Forecasting component  (30%)
# ---------------------------------------------------------------------------

def _compute_forecast_score(
    close: pd.Series,
    forecast_price: float | None = None,
) -> ComponentScore:
    """
    Directional score from the price forecast.
    forecast_price comes from Prophet / TimesFM ensemble in models/forecaster.py.

    If no external forecast is available, fall back to a simple
    linear-regression 1-step extrapolation as a placeholder.

    Score = clip((forecast - last) / last * 50, -1, 1)
    The *50 amplifier maps a 2% move to a ±1 score.
    """
    last_price = float(close.iloc[-1])

    if forecast_price is None:
        # Naive 5-day linear extrapolation
        tail = close.tail(20).values
        x    = np.arange(len(tail))
        slope, intercept = np.polyfit(x, tail, 1)
        forecast_price = float(intercept + slope * (len(tail)))

    expected_return = (forecast_price - last_price) / max(abs(last_price), 1e-8)
    raw_score       = float(np.clip(expected_return * 50.0, -1.0, 1.0))

    if raw_score > 0.05:
        sig = BUY
    elif raw_score < -0.05:
        sig = SELL
    else:
        sig = NEUTRAL

    detail = (
        f"Last={last_price:.2f}  Forecast={forecast_price:.2f}  "
        f"Δ={expected_return:.2%}"
    )
    return ComponentScore(
        name="Forecasting Model",
        raw_score=raw_score,
        signal=sig,
        weight=W_FORE,
        detail=detail,
        sub_signals={
            "last_price":     last_price,
            "forecast_price": forecast_price,
            "expected_return": expected_return,
        },
    )


# ---------------------------------------------------------------------------
# Master aggregator
# ---------------------------------------------------------------------------

def compute_ensemble_signal(
    ticker: str,
    ohlcv: pd.DataFrame,
    news_headlines: list[str] | None = None,
    forecast_price: float | None = None,
) -> EnsembleSignal:
    """
    Compute the weighted Majority Consensus Final Signal.

    Parameters
    ----------
    ticker          : Equity ticker symbol
    ohlcv           : OHLCV DataFrame (columns: open, high, low, close, volume)
    news_headlines  : Optional list of raw news/tweet strings for sentiment
    forecast_price  : Optional price prediction from Prophet / TimesFM ensemble

    Returns
    -------
    EnsembleSignal  : Fully populated ensemble result
    """
    close = ohlcv["close"] if "close" in ohlcv.columns else ohlcv.iloc[:, 3]

    # Score each component
    tech_comp = _compute_technical_score(ohlcv)
    sent_comp = _compute_sentiment_score(ticker, news_headlines)
    fore_comp = _compute_forecast_score(close, forecast_price)

    components = [tech_comp, sent_comp, fore_comp]

    # Weighted ensemble score
    ensemble_score = sum(c.weighted_score() for c in components)
    ensemble_score = float(np.clip(ensemble_score, -1.0, 1.0))

    # Final signal determination
    if ensemble_score >= 0.15:
        final_signal = BUY
    elif ensemble_score <= -0.15:
        final_signal = SELL
    else:
        final_signal = NEUTRAL

    # Confidence = |ensemble| mapped to [0.50, 0.95]
    confidence = float(np.clip(0.50 + 0.45 * abs(ensemble_score), 0.50, 0.95))

    # Count technical sub-signals
    sub = tech_comp.sub_signals
    return EnsembleSignal(
        ticker=ticker,
        timestamp=pd.Timestamp.now().strftime("%Y-%m-%d %H:%M:%S"),
        final_signal=final_signal,
        confidence=confidence,
        ensemble_score=ensemble_score,
        components=components,
        buy_count=int(sub.get("buy_count", 0)),
        sell_count=int(sub.get("sell_count", 0)),
        neutral_count=int(sub.get("neutral_count", 0)),
        total_indicators=int(sub.get("total", 0)),
    )


def build_signal_component_df(signal: EnsembleSignal) -> pd.DataFrame:
    """Convert ensemble components to a tidy DataFrame for display."""
    rows = []
    for c in signal.components:
        rows.append({
            "Component":      c.name,
            "Weight":         f"{c.weight:.0%}",
            "Raw Score":      round(c.raw_score, 3),
            "Weighted Score": round(c.weighted_score(), 3),
            "Signal":         c.signal,
            "Detail":         c.detail,
        })
    rows.append({
        "Component":      "ENSEMBLE",
        "Weight":         "100%",
        "Raw Score":      round(signal.ensemble_score, 3),
        "Weighted Score": round(signal.ensemble_score, 3),
        "Signal":         signal.final_signal,
        "Detail":         f"Confidence: {signal.confidence:.0%}",
    })
    return pd.DataFrame(rows)
